Live fast, die young, and leave a flat patch of fur on the highway!
                -- The Squirrels' Motto (The "Hell's Angels of Nature")
